package com.mkyong.customer.model;

public class Customer{
	
	String secretValue;

	public String getSecretValue() {
		return secretValue;
	}

	public void setSecretValue(String secretValue) {
		this.secretValue = secretValue;
	}
	
}